These go in your server addons folder.

I also ran this server-side mod for spawning NPCs in custom areas: https://steamcommunity.com/workshop/filedetails/?id=2482312670